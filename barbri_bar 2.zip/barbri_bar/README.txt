
NOTE: 
- There is a minor bug with "Problem Number". Some "Real Property" problems are mislabelled as "Torts." Because of this, the indices on the final output.json is not unique. This is most likely due to an index error in lines 139-147. I will fix this later.  

- This script produces 390 problems. This seems too few. I will see if there are any bugs that are preventing collection of more problems.